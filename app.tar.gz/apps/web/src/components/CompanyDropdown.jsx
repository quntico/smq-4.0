
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const CompanyDropdown = ({ isOpen, onMouseEnter, onMouseLeave }) => {
  const items = [
    { label: 'Nosotros', href: '#nosotros' },
    { label: 'Proyectos', href: '#proyectos' },
    { label: 'Certificaciones', href: '#certificaciones' },
    { label: 'Descargables', href: '#descargables' },
    { label: 'Contacto', href: '#contacto' }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          className="absolute top-full left-0 mt-4 w-[280px] bg-[#1A1F2E] py-[20px] rounded-[8px] border border-white/10 shadow-[0_10px_40px_rgba(0,0,0,0.3)] z-[999]"
          onMouseEnter={onMouseEnter}
          onMouseLeave={onMouseLeave}
        >
          <ul className="flex flex-col">
            {items.map((item, index) => (
              <li key={index}>
                <a
                  href={item.href}
                  className="block px-[20px] py-[12px] text-[14px] text-[#E5E7EB] hover:bg-[rgba(10,132,255,0.1)] hover:text-[#0A84FF] transition-all duration-150"
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CompanyDropdown;
