
import React, { useState, useRef } from 'react';
import { Menu, ChevronDown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import IndustriesMegaMenu from '@/components/IndustriesMegaMenu.jsx';
import SolutionsDropdown from '@/components/SolutionsDropdown.jsx';
import TechnologyDropdown from '@/components/TechnologyDropdown.jsx';
import CompanyDropdown from '@/components/CompanyDropdown.jsx';
import MobileMenu from '@/components/MobileMenu.jsx';

const Header = () => {
  const navigate = useNavigate();
  const [activeMenu, setActiveMenu] = useState(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const timeoutRef = useRef(null);

  const handleLogoClick = (e) => {
    e.preventDefault();
    navigate('/');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleMouseEnter = (menu) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    setActiveMenu(menu);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => {
      setActiveMenu(null);
    }, 250);
  };

  const closeMenu = () => {
    setActiveMenu(null);
  };

  const NavItem = ({ label, menuName, DropdownComponent }) => (
    <div 
      className="relative h-full flex items-center"
      onMouseEnter={() => handleMouseEnter(menuName)}
      onMouseLeave={handleMouseLeave}
    >
      <button
        className={`flex items-center gap-1 text-[16px] font-medium py-[8px] transition-colors duration-200 ${
          activeMenu === menuName ? 'text-[#0A84FF]' : 'text-[#FFFFFF] hover:text-[#0A84FF]'
        }`}
      >
        {label}
        <ChevronDown 
          size={16} 
          className={`transition-transform duration-200 ${activeMenu === menuName ? 'rotate-180' : ''}`} 
        />
      </button>
      
      <DropdownComponent 
        isOpen={activeMenu === menuName} 
        onMouseEnter={() => handleMouseEnter(menuName)}
        onMouseLeave={handleMouseLeave}
        onClose={closeMenu}
      />
    </div>
  );

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-[1000] h-[100px] bg-[#0B0F14] px-[40px] flex items-center border-b border-white/5 font-['Poppins'] transition-all duration-300">
        {/* Logo */}
        <button 
          onClick={handleLogoClick} 
          className="mr-auto focus:outline-none flex items-center relative h-full"
          aria-label="Go to home"
        >
          <div className="w-[230px] h-full relative">
            <img 
              src="https://horizons-cdn.hostinger.com/97ce7f08-d33c-4278-88dd-69ce1a127c81/18cd38f968eed96d842606d6f02d0311.png" 
              alt="SMQ Industrial Systems Logo" 
              className="h-[182px] pl-[48px] w-auto object-contain absolute top-1/2 -translate-y-1/2 left-0 max-w-none"
            />
          </div>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center h-full gap-[40px] absolute left-1/2 -translate-x-1/2">
          <NavItem label="Industrias" menuName="industrias" DropdownComponent={IndustriesMegaMenu} />
          <NavItem label="Soluciones" menuName="soluciones" DropdownComponent={SolutionsDropdown} />
          <NavItem label="Tecnología" menuName="tecnologia" DropdownComponent={TechnologyDropdown} />
          <NavItem label="Empresa" menuName="empresa" DropdownComponent={CompanyDropdown} />
        </nav>

        {/* Desktop CTA */}
        <div className="hidden lg:block ml-auto">
          <a 
            href="#cotizar"
            className="inline-block bg-[#FFD700] text-[#1A1F2E] font-semibold text-[16px] py-[12px] px-[30px] rounded-[10px] transition-all duration-200 hover:brightness-110 hover:shadow-[0_4px_15px_rgba(255,215,0,0.3)]"
          >
            Cotizar
          </a>
        </div>

        {/* Mobile Hamburger Menu */}
        <button
          className="lg:hidden text-[#FFFFFF] hover:text-[#0A84FF] transition-colors duration-200 ml-auto"
          onClick={() => setIsMobileMenuOpen(true)}
          aria-label="Toggle menu"
        >
          <Menu size={28} />
        </button>
      </header>

      <MobileMenu 
        isOpen={isMobileMenuOpen} 
        onClose={() => setIsMobileMenuOpen(false)} 
      />
    </>
  );
};

export default Header;
