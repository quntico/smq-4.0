
import React, { useEffect, useRef, useState } from 'react';
import { Recycle, UtensilsCrossed, Package, Factory } from 'lucide-react';
import { motion } from 'framer-motion';

const IndustriesSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const industries = [
    {
      icon: Recycle,
      title: 'Reciclaje de Plásticos',
      description: 'Sistemas completos de extrusión, pelletizado y lavado para transformar residuos plásticos en materia prima de alta calidad.',
    },
    {
      icon: UtensilsCrossed,
      title: 'Procesamiento de Alimentos',
      description: 'Maquinaria especializada para chocolate, confitería y procesamiento industrial con estándares de calidad internacional.',
    },
    {
      icon: Package,
      title: 'Maquinaria de Empaque',
      description: 'Soluciones automatizadas de empaque y envasado para optimizar la producción y garantizar la calidad del producto final.',
    },
    {
      icon: Factory,
      title: 'Sistemas Industriales Completos',
      description: 'Diseño, instalación y puesta en marcha de plantas industriales completas con tecnología de vanguardia.',
    },
  ];

  return (
    <section id="industrias" ref={sectionRef} className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 md:mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Industrias que <span className="text-primary">Transformamos</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Soluciones especializadas para cada sector industrial con tecnología de punta
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
          {industries.map((industry, index) => (
            <motion.div
              key={industry.title}
              initial={{ opacity: 0, y: 50 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="glass-card rounded-xl p-8 hover:scale-105 hover:border-primary transition-all duration-300 group cursor-pointer border border-transparent"
            >
              <div className="w-16 h-16 rounded-lg bg-primary/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 glow-blue">
                <industry.icon size={32} className="text-primary" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">
                {industry.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {industry.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default IndustriesSection;
